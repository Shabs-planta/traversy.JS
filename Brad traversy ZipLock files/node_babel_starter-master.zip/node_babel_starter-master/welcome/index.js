// Custom module example

const welcome = 'Node-Babel Starter Pack';

export default welcome;
